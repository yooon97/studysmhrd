package test;

public class ex02 {

	
	public static void main(String[] args) {
	
		int a = 0;
		
		
		
		for(int c=1; c<10; c++) {
				a++;
			for(int j=2; j<10; j++) {
				
				System.out.print(j + "X"+ a + "=" + j*a + "\t");
			
			}
		System.out.println();
		}
	}
}


