
public class Piggybank {
	
	
	private int money;
	
	
	
public void showMoney() {
	System.out.println("�ܾ��� : " +money + " �Դϴ�.");
}
public void deposit(int inputmoney) {
	money += inputmoney;
	
}
public void minus(int outputmoney) {
	money -= outputmoney;
}




}

