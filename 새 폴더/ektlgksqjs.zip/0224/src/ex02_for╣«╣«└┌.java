
public class ex02_for������ {

	public static void main(String[] args) {
		
//		for(char i = 'a'; i <= 'z'; i++) {
//			System.out.print(i + " ");
//		}
		for(char i = 65; i<=90; i++) {
			System.out.print(i + " ");
		}
	}
}
