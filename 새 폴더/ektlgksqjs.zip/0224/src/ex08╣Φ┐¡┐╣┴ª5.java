
public class ex08�迭����5 {
	public static void main(String[] args) {
		int[] starcount = {3,4,4,2,1};
		for(int i=0; i<starcount.length; i++) {
			System.out.print(starcount[i] + " : ");
		for(int a=0; a<starcount[i]; a++) {
			System.out.print("*");
			
		}System.out.println();
		}
	}
}	
			
		
		



