import java.util.Scanner;

public class ex08����for��1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		
		System.out.print("���ϴ� �� : ");
		int dan = sc.nextInt();
		System.out.print("���ϴ� �� : ");
		int su = sc.nextInt();
			for(int a = 1; a<=su; a++) {
			System.out.println(dan + "*" + a +"=" + dan*a);
			}
		}
		
		
		
		
		
		
}
