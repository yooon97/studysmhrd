
public class ex07_������ {

	public static void main(String[] args) {
		
		
		for(int b = 2; b<9; b++) {
			for(int a = 1; a<10; a++) {
				System.out.println(b + "*" + a +"=" + b*a);
		}
			}
		
		
		
		
		
		
	}

}

