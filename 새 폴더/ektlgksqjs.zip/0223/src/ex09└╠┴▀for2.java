
public class ex09����for2 {
	public static void main(String[] args) {
		
		for(int b = 2; b<10; b++) {
			System.out.println();
			System.out.print(b + "�� : " + " ");
			
			for(int a = 1; a<10; a++) {
				System.out.print( b + "X" + a +"=" + b*a+ " ");
				
			}
			
			}
		
		
	}
}
