
public class adfadfdaf {

	public static void main(String[] args) {
		for(int a = 1; a<6; a++) {
			for(int b=0; b<5-a; b++) {
				System.out.print(" ");
			}
			for(int c = 0; c<a*2-1; c++) {
				System.out.print("*");
						
			}
			System.out.println();
		}
	}
}


	

