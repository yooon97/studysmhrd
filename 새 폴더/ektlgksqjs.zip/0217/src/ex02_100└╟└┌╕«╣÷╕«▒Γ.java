
public class ex02_100���ڸ������� {

	public static void main(String[] args) {
		
		int num1 = 456;
		int num2 = 111;
		
		
		System.out.println(num1/100*100);
		System.out.println(num2/100*100);
		
		
		
		
		
		
	}

}
