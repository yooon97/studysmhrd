
public class ex03_��������ȯ {

	public static void main(String[] args) {
		
		int num = 777;
		
		System.out.println(num/10*10+1);
		
		
		
		
		
		
		
		
		
		
	}

}
