package study111;
import java.util.*;
public class Main{
   public static void main(String args[]){
	
		int a = 2;
		
		int b = 1;
		
		if(a>b) {
			System.out.println(">");
		}else if(a<b) {
			System.out.println("<");
		}else if(a==b) {
			System.out.println("==");
		}
	
   }
}
