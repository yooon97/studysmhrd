
public class ex05�޼ҵ�7 {

	public static void main(String[] args) {
		
	}

}
